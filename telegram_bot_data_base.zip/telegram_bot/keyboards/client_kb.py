from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

b1=KeyboardButton('График работы')
b2=KeyboardButton('Расположение')
b3=KeyboardButton('Фоточки)')
b4=KeyboardButton('Информация')
b5=KeyboardButton('Слить свой номер', request_contact=True)
b6=KeyboardButton('Слить свою геолокацию', request_location=True)

kb_client=ReplyKeyboardMarkup(resize_keyboard=True)

kb_client.add(b1).insert(b2).add(b3).insert(b4).row(b5,b6)