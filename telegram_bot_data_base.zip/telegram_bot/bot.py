from aiogram.utils import executor
from create_bot import dp
from data_base import sqlite_db

sqlite_db.sql_start()

from handlers import client, admin, other

client.register_handlers_client(dp)
admin.register_handlers_admin(dp)

other.register_handlers_other(dp) #Это фильтр мата по этому он пишится ниже основного кода






executor.start_polling(dp, skip_updates=True, )
