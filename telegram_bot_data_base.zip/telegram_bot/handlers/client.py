from aiogram import types, Dispatcher
from create_bot import dp, bot
from keyboards import kb_client
from aiogram.types import ReplyKeyboardRemove
import logging,time
from data_base import sqlite_db


#@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    
    user_id = message.from_user.full_name
    user_full_name=message.from_user.full_name
    logging.info(f'{user_id=} {user_full_name=} {time.asctime()}')
    await message.reply(f'Привет, {user_full_name}!')
    
    await bot.send_message(message.from_user.id, 'Что вы хотите узнать?',reply_markup=kb_client)

#@dp.message_handler(commands=['старт','help'])
async def commands_start(message :  types.Message):
    try: 
        await bot.send_message(message.from_user.id, 'Что вы хотите?', reply_markup=kb_client)
        await message.delete()
    except:
        await message.reply('Общение с ботом через ЛС, напишите ему: \nhttps://t.me/BCKER_bot')

#@dp.message_handler(commands=['График_работы'])
async def pizza_open_command(message: types.Message):
    await bot.send_message(message.from_user.id, 'Вс-Чт с 9 до 20 , Пт-Сб с 10 до 23')
    await message.delete()

#@dp.message_handler(commands=['Расположение'])
async def pizza_place_command(message: types.Message):
    await bot.send_message(message.from_user.id, 'ул. Колбасная 15')
    await message.delete()

#@dp.message_handler(commands=['О_боте'])
async def command_info(message: types.Message):
    await bot.send_message(message.from_user.id, 'Чат бот Bocker был создан 1 программистом который оч любит заниматься саморазрушением). Мы не веним его в этом, ведь мы все в душе прокрастинаторы.')
    await message.delete()



@dp.message_handler(commands=['Фоточки)'])
async def pizza_menu_command(message:types.Message):
    await sqlite_db.sql_read(message)

@dp.message_handler(lambda message: 'График' in message.text) 
async def graphic(message: types.Message):
    await message.answer('Мы работаем с Вс-Чт с 9 до 20 , Пт-Сб с 10 до 23')
    await message.delete()

@dp.message_handler(lambda message: 'Фото' in message.text) 
async def photo(message: types.Message):
    await message.answer('Вот список фото')
    await message.delete()
    await sqlite_db.sql_read(message)

@dp.message_handler(lambda message: 'Расположение' in message.text) 
async def geolocation(message: types.Message):
    await message.answer('Мы находимся по адресу, ул. Колбасная 15')
    await message.delete()
    
@dp.message_handler(lambda message: 'Инф' in message.text) 
async def info(message: types.Message):
    await message.answer('Чат бот Bocker был создан 1 программистом который оч любит заниматься саморазрушением). Мы не веним его в этом, ведь мы все в душе прокрастинаторы.')
    await message.delete()




def register_handlers_client(dp : Dispatcher):
    dp.register_message_handler(start_handler, commands=['start', 'help'])
    dp.register_message_handler(pizza_open_command, commands=['График_работы'])
    dp.register_message_handler(pizza_place_command, commands=['Расположение'])
    dp.register_message_handler(command_info, commands=['О_боте'])
    dp.register_message_handler(pizza_menu_command,commands=['Фоточки)'])
    
