from aiogram import Bot
from aiogram.dispatcher import Dispatcher
import os
from aiogram.contrib.fsm_storage.memory import MemoryStorage

storage=MemoryStorage()

TOKEN='6018441551:AAHgVRURAplFPzXJxhys64JApf7Ffc0zZKc'

bot=Bot(token=TOKEN)
dp=Dispatcher(bot, storage=storage)